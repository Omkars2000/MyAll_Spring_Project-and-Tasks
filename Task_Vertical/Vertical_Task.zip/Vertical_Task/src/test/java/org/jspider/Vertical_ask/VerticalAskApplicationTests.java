package org.jspider.Vertical_ask;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerticalAskApplicationTests {

	@Test
	void contextLoads() {
	}

}
